package com.tek.interview.question;

import java.text.ParseException;
import java.util.Map;

public class Calculator {

	/**
	 * receives a collection of orders. For each order, iterates on the order lines and calculate the total price which
	 * is the item's price * quantity * taxes.
	 * 
	 * For each order, print the total Sales Tax paid and Total price without taxes for this order
	 * @throws ParseException 
	 */
	public double calculate(Map<String, Order> o,double grandtotal) throws ParseException {

		// Iterate through the orders
		for (Map.Entry<String, Order> entry : o.entrySet()) {
			System.out.println("*******" + entry.getKey() + "*******");
		
			Order r = entry.getValue();

			double totalTax = 0;
			double total = 0;
			String val = "";

			// Iterate through the items in the order
			for (int i = 0; i < r.size(); i++) { 

				// Calculate the taxes
				double tax = 0;
				double tax1 = 0;
				if (r.get(i).getItem().getDescription().contains("imported")) {
					tax = r.get(i).getItem().getPrice() * 0.15; // Extra 5% tax on 
					val = String.format("%.02f", tax);
					
					 tax1  = Double.parseDouble(val);
					// imported items
				} else {
					tax = r.get(i).getItem().getPrice() * 0.10; 
					val = String.format("%.02f", tax);			
					 tax1  = Double.parseDouble(val);
				}

				// Calculate the total price
				double totalprice = r.get(i).getItem().getPrice() +tax1;  
				val = String.format("%.02f", totalprice);
				double totalprice1  = Double.parseDouble(val);
				// Print out the item's total price 
				System.out.println(r.get(i).getItem().getDescription() + ": " + totalprice1);  

				// Keep a running total
				totalTax += tax1;
				total += r.get(i).getItem().getPrice();
			}

			val = String.format("%.02f", totalTax);
			double totalTax1  = Double.parseDouble(val);
			// Print out the total taxes
			System.out.println("Sales Tax: " + totalTax1); 

			total = total + totalTax1;
			val = String.format("%.02f", total);
			double total1  = Double.parseDouble(val);
			total1 = total1 - totalTax1;
			
			val = String.format("%.02f", total1);
			double totalval  = Double.parseDouble(val);
			
			// Print out the total amount
			System.out.println("Total: " + totalval);  
			grandtotal = grandtotal + total1;
			if(entry.getKey() == "Order 3"){
				System.out.println("Sum of orders: " + grandtotal * 100 / 100);
			}
		}
		return grandtotal;
	}
}