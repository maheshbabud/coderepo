package com.tek.interview.question.test;
import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import com.tek.interview.question.*;


public class FooTest {
	private static final double DELTA = 1e-15;
	@Test
	public void calculateEquals() throws Exception{
		double expectedTotal = 153.81;
		
		Calculator cal = new Calculator();
		Order c = new Order();
		Map<String,Order> map = new HashMap<String, Order>();
		c.add(new OrderLine(new Item("1 book", 12.49f), 1));
		c.add(new OrderLine(new Item("1 music CD", 14.99f), 1));
		c.add(new OrderLine(new Item("1 chocolate bar", 0.85f), 1));
		
		map.put("Order 1", c);
		double grandTotal= cal.calculate(map,0.0);
		c.clear();
		map.clear();

		c.add(new OrderLine(new Item("1 imported box of chocolate", 10f), 1));
		c.add(new OrderLine(new Item("1 imported bottle of perfume", 47.50f), 1));

		map.put("Order 2", c);
		grandTotal= cal.calculate(map,grandTotal);
		
		c.clear();
		map.clear();

		c.add(new OrderLine(new Item("1 imported bottle of perfume", (float) 27.99), 1));
		c.add(new OrderLine(new Item("1 bottle of perfume", (float) 18.99), 1));
		c.add(new OrderLine(new Item("1 packet of headache pills", (float) 9.75), 1));
		c.add(new OrderLine(new Item("1 box of imported chocolates", (float) 11.25), 1));

		map.put("Order 3", c);

		grandTotal = cal.calculate(map,grandTotal);
		
		assertEquals(expectedTotal,grandTotal,DELTA);
	}
	
	
	
	@Test
	public void calculateNoEquals() throws Exception{
		double expectedTotal = 153.81;
		
		Calculator cal = new Calculator();
		Order c = new Order();
		Map<String,Order> map = new HashMap<String, Order>();
		c.add(new OrderLine(new Item("1 book", 12.49f), 1));
		c.add(new OrderLine(new Item("1 music CD", 14.99f), 1));
		c.add(new OrderLine(new Item("1 chocolate bar", 2.85f), 1));
		
		map.put("Order 1", c);
		double grandTotal= cal.calculate(map,0.0);
		c.clear();
		map.clear();

		c.add(new OrderLine(new Item("1 imported box of chocolate", 10.25f), 1));
		c.add(new OrderLine(new Item("1 imported bottle of perfume", 47.50f), 1));

		map.put("Order 2", c);
		grandTotal= cal.calculate(map,grandTotal);
		
		c.clear();
		map.clear();

		c.add(new OrderLine(new Item("1 imported bottle of perfume", (float) 27.99), 1));
		c.add(new OrderLine(new Item("1 bottle of perfume", (float) 85.99), 1));
		c.add(new OrderLine(new Item("1 packet of headache pills", (float) 9.75), 1));
		c.add(new OrderLine(new Item("1 box of imported chocolates", (float) 11.25), 1));

		map.put("Order 3", c);

		grandTotal = cal.calculate(map,grandTotal);
		assertFalse(expectedTotal == grandTotal);
	}
	
	
	@Test(expected=NullPointerException.class)
	public void checkNullDescriptions() throws Exception{
		double expectedTotal = 153.81;
		
		Calculator cal = new Calculator();
		Order c = new Order();
		Map<String,Order> map = new HashMap<String, Order>();
		c.add(new OrderLine(new Item(null, 12.49f), 1));
		c.add(new OrderLine(new Item(null, 14.99f), 1));
		c.add(new OrderLine(new Item(null, 2.85f), 1));
		
		map.put("Order 1", c);
		double grandTotal= cal.calculate(map,0.0);
		c.clear();
		map.clear();

		c.add(new OrderLine(new Item("1 imported box of chocolate", 10.25f), 1));
		c.add(new OrderLine(new Item("1 imported bottle of perfume", 47.50f), 1));

		map.put("Order 2", c);
		grandTotal= cal.calculate(map,grandTotal);
		
		c.clear();
		map.clear();

		c.add(new OrderLine(new Item("1 imported bottle of perfume", (float) 27.99), 1));
		c.add(new OrderLine(new Item("1 bottle of perfume", (float) 85.99), 1));
		c.add(new OrderLine(new Item("1 packet of headache pills", (float) 9.75), 1));
		c.add(new OrderLine(new Item("1 box of imported chocolates", (float) 11.25), 1));

		map.put("Order 3", c);

		grandTotal = cal.calculate(map,grandTotal);
		assertEquals(expectedTotal,grandTotal,DELTA);
	}
}
