package com.angular.rest.controller;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.angular.rest.model.Employee;
import com.angular.rest.service.EmployeeServiceImpl;


@Path(value="employee")
public class EmployeeController {

	EmployeeServiceImpl employeeServiceImpl = new EmployeeServiceImpl();
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Employee addEmployee(Employee employee){
		return employeeServiceImpl.addEmployee(employee);
	}
	
	@DELETE
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public void deleteEmployee(@PathParam("id") int id){
		employeeServiceImpl.deleteEmployee(id);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Employee> getList(){
		return employeeServiceImpl.getList();
	}
	
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	public Employee updateEmployee(Employee employee){
		return employeeServiceImpl.updateEmployee(employee);
	}
	
	@DELETE
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
	public void deleteAll(){
		employeeServiceImpl.deleteAll();
	}
}
