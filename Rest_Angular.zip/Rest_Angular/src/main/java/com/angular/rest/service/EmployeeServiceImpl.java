package com.angular.rest.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.angular.rest.model.Employee;

public class EmployeeServiceImpl implements EmployeeService{

	static HashMap<Integer,Employee> employeeIdMap=getEmployeeIdMap(); 

	public EmployeeServiceImpl(){
		super();
		if(employeeIdMap == null){
			employeeIdMap = new HashMap<Integer, Employee>();

			Employee employee1= new Employee(1,"Mahesh","Java");
			Employee employee2= new Employee(2,"Mallesh","UI");
			Employee employee3= new Employee(3,"Nikhil","Java");
			Employee employee4= new Employee(4,"Pavan","Java");

			employeeIdMap.put(1, employee1);
			employeeIdMap.put(2, employee2);
			employeeIdMap.put(3, employee3);
			employeeIdMap.put(4, employee4);
 
		}
	}

	public Employee addEmployee(Employee employee) {

		employee.setEmpId(getMaxId()+1);
		employeeIdMap.put(employee.getEmpId(), employee);  
		return employee;

	}

	public List<Employee> getList() {
		List<Employee> employees = new ArrayList<Employee>(employeeIdMap.values());  
		return employees; 

	}

	public void deleteEmployee(int id) {
		employeeIdMap.remove(id);
	}

	public static int getMaxId()  
	{  
		int max=0;  
		for (int id:employeeIdMap.keySet()) {    
			if(max<=id)  
				max=id;  
		}    
		return max;  
	}  
	public static HashMap<Integer, Employee> getEmployeeIdMap() {  
		return employeeIdMap;  
	}

	@Override
	public Employee updateEmployee(Employee employee) {

		if(employee.getEmpId()<=0)  
			return null;  
		employeeIdMap.put(employee.getEmpId(), employee);  
		return employee;  
	}  

	@Override
	public void deleteAll(){
		employeeIdMap.clear();
	}

}
