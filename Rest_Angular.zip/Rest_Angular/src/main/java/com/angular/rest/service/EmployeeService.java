package com.angular.rest.service;

import java.util.List;

import com.angular.rest.model.Employee;

public interface EmployeeService{
	public Employee addEmployee(Employee employee);
	public Employee updateEmployee(Employee employee);
	public List<Employee> getList();
	public void deleteEmployee(int id);
	public void deleteAll();
}
